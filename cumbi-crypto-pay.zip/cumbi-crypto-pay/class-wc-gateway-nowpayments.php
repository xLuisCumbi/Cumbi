<?php

/**
 * @wordpress-plugin
 * Plugin Name:             Cumbi Crypto Payment Gateway
 * Plugin URI:              https://www.cumbi.cc/
 * Description:             Cryptocurrency Payment Gateway.
 * Version:                 1.0.0
 * Author:                  Cumbi
 * Author URI:              github.com/timileyin105
 * License:                 proprietary
 * License URI:             http://www..org/
 * Text Domain:             wc-cumbi-gateway
 * Domain Path:             /i18n/languages/
 * Requires at least:       5.5
 * Tested up to:            5.9
 * WC requires at least:    4.9.4
 * WC tested up to:         6.1.1
 *
 */

/**
 * Exit if accessed directly.
 */
if (!defined('ABSPATH')) {
    exit();
}

if (version_compare(phpversion(), '7.1', '>=')) {
    ini_set('precision', 10);
    ini_set('serialize_precision', 10);
}


if (!defined('CUMBIPAYMENT_FOR_WOOCOMMERCE_PLUGIN_DIR')) {
    define('CUMBIPAYMENT_FOR_WOOCOMMERCE_PLUGIN_DIR', dirname(__FILE__));
}
if (!defined('CUMBIPAYMENT_FOR_WOOCOMMERCE_ASSET_URL')) {
    define('CUMBIPAYMENT_FOR_WOOCOMMERCE_ASSET_URL', plugin_dir_url(__FILE__));
}
if (!defined('VERSION_PFW')) {
    define('VERSION_PFW', '1.0.0');
}


$base_directory = ABSPATH; // WordPress base directory path
$serverUrl = 'http://localhost:3000';
/**
 * Add the gateway to WC Available Gateways
 *
 * @since 1.0.0
 * @param array $gateways all available WC gateways
 * @return array $gateways all WC gateways + offline gateway
 */
function wc_cumbi_add_to_gateways($gateways)
{
    if (!in_array('WC_Gateway_cumbi', $gateways)) {
        $gateways[] = 'WC_Gateway_cumbi';
    }
    return $gateways;
}
add_filter('woocommerce_payment_gateways', 'wc_cumbi_add_to_gateways');

/**
 * Cumbi.cc Payment Gateway
 *
 * @class 		WC_Gateway_cumbi
 * @extends		WC_Payment_Gateway
 * @version		1.0.0
 * @package		WooCommerce/Classes/Payment
 * @author 		github.com/timileyin105
 */
add_action('plugins_loaded', 'wc_cumbi_gateway_init');

function wc_cumbi_gateway_init()
{

    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    class WC_Gateway_cumbi extends WC_Payment_Gateway
    {

        public function __construct()
        {
            global $woocommerce;
            $this->id = 'cumbi_gateway';
            $this->icon = apply_filters('woocommerce_cumbi_icon', plugins_url('/assets/images/cumbi.png', __FILE__));
            $this->has_fields = false;
            $this->method_title = __('Cumbi Crypto Payment Gateway', 'wc-gateway-cumbi');
            $this->method_description = __('Make payment using cumbi crypto payment', 'wc-cumbi-gateway');

            // Load the settings.
            $this->init_form_fields();
            $this->init_settings();

            // Define user set variables
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->api_key = $this->get_option('api_key');
            $this->instructions = $this->get_option('instructions');
            $this->debug_post_url = $this->get_option('debug_post_url');
            $this->invoice_prefix = $this->get_option('invoice_prefix', 'WC-');
            $this->simple_total = $this->get_option('simple_total') == 'yes' ? true : false;

            // Logs
            $this->log = new WC_Logger();

            // Actions
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));

            // Customer Emails
            add_action('woocommerce_email_before_order_table', array($this, 'email_instructions'), 10, 3);
        }


        function init_form_fields()
        {
            require_once('includes/setting_form_fields.php');
        }


        public function process_payment($order_id)
        {
            global $serverUrl;
            // Update the order status
            $order = wc_get_order($order_id);
            $order->update_status('pending', 'Awaiting Customer Payment');
            //$woocommerce->cart->empty_cart();
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }

            $amount = $order->get_total();
            $wp_order_received_url = $order->get_checkout_order_received_url();

            $paymentObj = $this->fetchPaymentObject($order_id, $amount, $wp_order_received_url, 'create');
            if($paymentObj->status == 'success'){

                return array(
                    'result' => 'success',
                    'redirect' => $serverUrl.'/payment/'.$order_id
                );

            }else{
                header('Location:  /checkout');
            }

        }


        public function fetchPaymentObject($order_id, $amount = null, $wp_order_received_url =null, $endpoint)
        {
            global $serverUrl;

            $url = $serverUrl.'/api/deposit/'.$endpoint;
            $token = $this->api_key;
            $data = array(
                'amount' => $amount,
                'deposit_id' => $order_id,
                'wp_order_received_url' => $wp_order_received_url,
                'type' => 'wp-payment'
            );

            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Authorization: Bearer ' . $token,
                'Content-Type: application/json',
            )
            );
            $response = curl_exec($curl);
            if (curl_errno($curl)) {

                header('Location:  /checkout');
            }
            curl_close($curl);

            if ($response) {

                return json_decode($response);

            } else {

                header('Location:  /checkout');
            }

        }

        public function thankyou_page($order_id)
        {
            $order = wc_get_order($order_id);

            $paymentObj = $this->fetchPaymentObject($order_id, null, null, 'status');
        $paymentObj = $paymentObj->depositObj;
            if($paymentObj->status === 'success'){

                $order->update_status('completed', 'Order completed successfully');
                echo
                    "
                    <div style='text-align: center'>
                        <svg style='margin-right:5px;display:block;margin:0px auto' xmlns='http://www.w3.org/2000/svg' width='80' height='80' fill='green' class='bi bi-check-circle' viewBox='0 0 16 16'> <path d='M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z'/> <path d='M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z'/> </svg>

                    ";
                echo "<p>" . __('Your Order is being processed Thank you for your purchase!', 'your-plugin-domain') . "</p>";

                echo "</div>";

            }else if($paymentObj->status === 'pending'){

                $order->update_status('pending', 'Order Pending Payment');
                echo
                    "
                    <div style='text-align: center'>
                    <svg style='margin-right:5px;display:block;margin:0px auto' xmlns='http://www.w3.org/2000/svg' width='80' height='80' fill='#5271ff' class='bi bi-hourglass-split' viewBox='0 0 16 16'>
                    <path d='M2.5 15a.5.5 0 1 1 0-1h1v-1a4.5 4.5 0 0 1 2.557-4.06c.29-.139.443-.377.443-.59v-.7c0-.213-.154-.451-.443-.59A4.5 4.5 0 0 1 3.5 3V2h-1a.5.5 0 0 1 0-1h11a.5.5 0 0 1 0 1h-1v1a4.5 4.5 0 0 1-2.557 4.06c-.29.139-.443.377-.443.59v.7c0 .213.154.451.443.59A4.5 4.5 0 0 1 12.5 13v1h1a.5.5 0 0 1 0 1h-11zm2-13v1c0 .537.12 1.045.337 1.5h6.326c.216-.455.337-.963.337-1.5V2h-7zm3 6.35c0 .701-.478 1.236-1.011 1.492A3.5 3.5 0 0 0 4.5 13s.866-1.299 3-1.48V8.35zm1 0v3.17c2.134.181 3 1.48 3 1.48a3.5 3.5 0 0 0-1.989-3.158C8.978 9.586 8.5 9.052 8.5 8.351z'/>
                  </svg>

                    ";
                echo "<p>" . __('Your Order is pending  awaiting payment confirmation: Kinldy complete payment', 'your-plugin-domain') . "</p>";

                echo "</div>";
                
            }else{
                    $order->update_status('cancelled', 'Order completed successfully');
                    echo
                    "
                        <div style='text-align: center'>
                        <svg style='margin-right:5px;display:block;margin:0px auto'  xmlns='http://www.w3.org/2000/svg' width='80' height='80' fill='red' class='bi bi-x-octagon' viewBox='0 0 16 16'> <path d='M4.54.146A.5.5 0 0 1 4.893 0h6.214a.5.5 0 0 1 .353.146l4.394 4.394a.5.5 0 0 1 .146.353v6.214a.5.5 0 0 1-.146.353l-4.394 4.394a.5.5 0 0 1-.353.146H4.893a.5.5 0 0 1-.353-.146L.146 11.46A.5.5 0 0 1 0 11.107V4.893a.5.5 0 0 1 .146-.353L4.54.146zM5.1 1 1 5.1v5.8L5.1 15h5.8l4.1-4.1V5.1L10.9 1H5.1z'/> <path d='M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z'/> </svg>

                    ";
                    echo "<p>" . __('Opps Payment Failed, No Payment Detected Within Payment Window, Order Cancelled', 'your-plugin-domain') . "</p>";

                    echo "</div>";

            }

        }

    }

}