<?php


$this->form_fields = apply_filters('wc_offline_form_fields', array(

    'enabled' => array(
        'title' => __('Enable/Disable', 'wc-highrollas-gateway'),
        'type' => 'checkbox',
        'label' => __('Enable cumbi', 'wc-highrollas-gateway'),
        'default' => 'yes',
    ),
    'title' => array(
        'title' => __('Title', 'wc-highrollas-gateway'),
        'type' => 'text',
        'description' => __('This controls the title which the user sees during checkout.', 'wc-highrollas-gateway'),
        'default' => __('Highrollas', 'wc-highrollas-gateway'),
        'desc_tip' => true,
    ),
    'api_key' => array(
        'title' => __('Api Key', 'wc-highrollas-gateway'),
        'type' => 'text',
        'description' => __('This is used for api authentication', 'wc-highrollas-gateway'),
        'desc_tip' => true,
    ),
    'description' => array(
        'title' => __('Description', 'wc-highrollas-gateway'),
        'type' => 'textarea',
        'description' => __('This controls the description which the user sees during checkout.', 'wc-highrollas-gateway'),
        'default' => __('Make payment using high rollas crypto payment gateway', 'wc-highrollas-gateway'),
    ),
    'instructions' => array(
        'title' => __('Instructions', 'wc-gateway-offline'),
        'type' => 'textarea',
        'description' =>  __('This controls the instructions which the user sees during checkout.', 'wc-highrollas-gateway'),
        'default' =>  __('send exact or greater than the crypto amount amount to complete payment', 'wc-highrollas-gateway'),
        'desc_tip' => true,
    ),
    'simple_total' => array(
        'title' => __('Compatibility Mode', 'wc-highrollas-gateway'),
        'type' => 'checkbox',
        'label' => __("This may be needed for compatibility with certain addons if the order total isn't correct.", 'wc-highrollas-gateway'),
        'default' => '',
    ),
    'invoice_prefix' => array(
        'title' => __('Invoice Prefix', 'wc-highrollas-gateway'),
        'type' => 'text',
        'description' => __('Please enter a prefix for your invoice numbers. If you use your cumbi account for multiple stores ensure this prefix is unique.', 'wc-highrollas-gateway'),
        'default' => 'ORD-',
        'desc_tip' => true,
    )
));