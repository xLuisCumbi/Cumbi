<?php


$this->form_fields = apply_filters('wc_offline_form_fields', array(

    'enabled' => array(
        'title' => __('Enable/Disable', 'wc-cumbi-gateway'),
        'type' => 'checkbox',
        'label' => __('Enable cumbi', 'wc-cumbi-gateway'),
        'default' => 'yes',
    ),
    'title' => array(
        'title' => __('Title', 'wc-cumbi-gateway'),
        'type' => 'text',
        'description' => __('This controls the title which the user sees during checkout.', 'wc-cumbi-gateway'),
        'default' => __('cumbi', 'wc-cumbi-gateway'),
        'desc_tip' => true,
    ),
    'server_url' => array(
        'title' => __('Server Url', 'wc-cumbi-gateway'),
        'type' => 'text',
        'description' => __('Server endpoint for gateway connection', 'wc-cumbi-gateway'),
        'desc_tip' => true,
    ),
    'api_key' => array(
        'title' => __('Api Key', 'wc-cumbi-gateway'),
        'type' => 'text',
        'description' => __('This is used for api authentication', 'wc-cumbi-gateway'),
        'desc_tip' => true,
    ),
    'description' => array(
        'title' => __('Description', 'wc-cumbi-gateway'),
        'type' => 'textarea',
        'description' => __('This controls the description which the user sees during checkout.', 'wc-cumbi-gateway'),
        'default' => __('Make payment using high rollas crypto payment gateway', 'wc-cumbi-gateway'),
    ),
    'instructions' => array(
        'title' => __('Instructions', 'wc-gateway-offline'),
        'type' => 'textarea',
        'description' =>  __('This controls the instructions which the user sees during checkout.', 'wc-cumbi-gateway'),
        'default' =>  __('send exact or greater than the crypto amount amount to complete payment', 'wc-cumbi-gateway'),
        'desc_tip' => true,
    ),
    'simple_total' => array(
        'title' => __('Compatibility Mode', 'wc-cumbi-gateway'),
        'type' => 'checkbox',
        'label' => __("This may be needed for compatibility with certain addons if the order total isn't correct.", 'wc-cumbi-gateway'),
        'default' => '',
    ),
    'invoice_prefix' => array(
        'title' => __('Invoice Prefix', 'wc-cumbi-gateway'),
        'type' => 'text',
        'description' => __('Please enter a prefix for your invoice numbers. If you use your cumbi account for multiple stores ensure this prefix is unique.', 'wc-cumbi-gateway'),
        'default' => 'ORD-',
        'desc_tip' => true,
    )
));